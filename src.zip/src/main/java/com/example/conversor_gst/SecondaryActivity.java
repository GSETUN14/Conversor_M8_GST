package com.example.conversor_gst;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.ArrayAdapter;
import androidx.appcompat.app.AppCompatActivity;

public class SecondaryActivity extends AppCompatActivity {

    private EditText editTextValue;
    private Spinner spinnerFrom, spinnerTo;
    private TextView textViewResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_secondary);

        editTextValue = findViewById(R.id.editTextValue);
        spinnerFrom = findViewById(R.id.spinnerFrom);
        spinnerTo = findViewById(R.id.spinnerTo);
        textViewResult = findViewById(R.id.textViewResult);
        Button buttonBack = findViewById(R.id.buttonBack);
        Button buttonConvert = findViewById(R.id.buttonConvert);

        String conversionType = getIntent().getStringExtra("conversionType");

        //Spinners model conversio
        setupSpinners(conversionType);

        // Boto "Tornar"
        buttonBack.setOnClickListener(v -> finish());

        // Boto "Convertir"
        buttonConvert.setOnClickListener(v -> convertValue());
    }

    private void setupSpinners(String conversionType) {
        String[] fromItems;
        String[] toItems;

        switch (conversionType) {
            case "Pes":
                fromItems = new String[]{"Microgram", "Miligram", "Gram", "Kilogram", "Tonelada"};
                toItems = fromItems; 
                break;
            case "Volum":
                fromItems = new String[]{"Mililitre", "Litre", "Metre cubic"};
                toItems = fromItems; 
                break;
            case "Distancia":
                fromItems = new String[]{"mm", "cm", "m", "km"};
                toItems = fromItems;
                break;
            case "Temperatura":
                fromItems = new String[]{"Celsius", "Fahrenheit", "Kelvin"};
                toItems = fromItems; 
                break;
            case "Capasitat Disc Dur":
                fromItems = new String[]{"bit", "bytes", "kb", "gb", "tb"};
                toItems = fromItems; 
                break;
            default:
                fromItems = new String[]{};
                toItems = new String[]{};
                break;
        }

        ArrayAdapter<String> fromAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, fromItems);
        ArrayAdapter<String> toAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, toItems);

        fromAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        toAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinnerFrom.setAdapter(fromAdapter);
        spinnerTo.setAdapter(toAdapter);
    }

    private void convertValue() {

        String valueStr = editTextValue.getText().toString();
        double value = Double.parseDouble(valueStr); 

        String fromUnit = spinnerFrom.getSelectedItem().toString();
        String toUnit = spinnerTo.getSelectedItem().toString();


        double convertedValue = performConversion(value, fromUnit, toUnit);


        textViewResult.setText(String.format("%.5f", convertedValue));
    }

    private double performConversion(double value, String fromUnit, String toUnit) {
        // Pes
        if (fromUnit.equals("Gram")) {
            switch (toUnit) {
                case "Kilogram": return value / 1000;
                case "Miligram": return value * 1000;
                case "Gram": return value;
            }
        }
        if (fromUnit.equals("Kilogram")) {
            switch (toUnit) {
                case "Gram": return value * 1000;
                case "Miligram": return value * 1_000_000;
                case "Kilogram": return value;
            }
        }
        if (fromUnit.equals("Miligram")) {
            switch (toUnit) {
                case "Gram": return value / 1000;
                case "Kilogram": return value / 1_000_000;
                case "Miligram": return value;
            }
        }

        // Volum
        if (fromUnit.equals("Litre")) {
            switch (toUnit) {
                case "Mililitre": return value * 1000;
                case "Metre cubic": return value / 1000;
                case "Litre": return value;
            }
        }
        if (fromUnit.equals("Mililitre")) {
            switch (toUnit) {
                case "Litre": return value / 1000;
                case "Metre cubic": return value / 1_000_000;
                case "Mililitre": return value;
            }
        }
        if (fromUnit.equals("Metre cubic")) {
            switch (toUnit) {
                case "Litre": return value * 1000;
                case "Mililitre": return value * 1_000_000;
                case "Metre cubic": return value;
            }
        }

        // Distància
        if (fromUnit.equals("m")) {
            switch (toUnit) {
                case "cm": return value * 100;
                case "km": return value / 1000;
                case "mm": return value * 1000;
                case "m": return value;
            }
        }
        if (fromUnit.equals("cm")) {
            switch (toUnit) {
                case "m": return value / 100;
                case "mm": return value * 10;
                case "km": return value / 100_000;
                case "cm": return value;
            }
        }

        // Temperatura
        if (fromUnit.equals("Celsius")) {
            switch (toUnit) {
                case "Fahrenheit": return (value * 9/5) + 32;
                case "Kelvin": return value + 273.15;
                case "Celsius": return value;
            }
        }
        if (fromUnit.equals("Fahrenheit")) {
            switch (toUnit) {
                case "Celsius": return (value - 32) * 5/9;
                case "Kelvin": return (value - 32) * 5/9 + 273.15;
                case "Fahrenheit": return value;
            }
        }
        if (fromUnit.equals("Kelvin")) {
            switch (toUnit) {
                case "Celsius": return value - 273.15;
                case "Fahrenheit": return (value - 273.15) * 9/5 + 32;
                case "Kelvin": return value;
            }
        }

        return value;
    }

}
